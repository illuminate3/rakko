Diversity
=========

Diversity – is a single page bootstrap template developed in material design

![Imgur](http://i.imgur.com/uRs436F.jpg)
