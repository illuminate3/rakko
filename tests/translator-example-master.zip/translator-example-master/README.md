Laravel Translator Example Application
======================================
This is an example Laravel application using the [Laravel Translator package](https://github.com/vinkla/translator).
