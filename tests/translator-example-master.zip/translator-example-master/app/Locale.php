<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Locale extends Model {

	/**
	 * @var array
	 */
	protected $fillable = ['language'];

}
